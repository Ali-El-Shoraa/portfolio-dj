document.addEventListener("DOMContentLoaded", function () {
  var typed2 = new Typed("#typed", {
    strings: ["Front-End Developer", "ReactJS Developer"],
    typeSpeed: 70,
    backSpeed: 20,
    loop: true,
  });
});
